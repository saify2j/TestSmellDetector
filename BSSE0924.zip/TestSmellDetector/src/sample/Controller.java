package sample;

import detector.*;
import detector.StatementsLine;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.paint.Paint;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

public class Controller {
    public Button saveButton;
    @FXML
    private TextField folderLoc;
    @FXML
    private Label detected;
    private String folderName = "";

    public void openFileChooser(ActionEvent actionEvent) {

        DirectoryChooser chooser = new DirectoryChooser();
        chooser.setTitle("Select Project Folder");
        File file = chooser.showDialog(new Stage());
        if (String.valueOf(file).equals("null")) {
            folderLoc.setText("Please Select A Project");
        } else {
            folderLoc.setText(String.valueOf(file));
            folderName = String.valueOf(file);
        }
    }

    @FXML
    private TextArea result;
    @FXML
    private Button testButton;
    public String[] smellOrNot = new String[100000];
    public void testSmell(ActionEvent actionEvent) {
        int smell = 0;
        if (folderName.equals("")) {

            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Project Not Selected");

            // Header Text: null
            alert.setHeaderText(null);
            alert.setContentText("Please select a project folder!");

            alert.showAndWait();
            detected.setText("");
        } else {
//        detected.setText(folderName);
            StatementsLine sl = new StatementsLine();
            ArrayList<Result> results = new ArrayList<>();
            results = sl.statementsByLine(new File(folderName));
            //System.out.println(results);
            StringBuilder fieldContent = new StringBuilder("");

            int count = 0;
            for (Result s : results) {
                //System.out.println(s.getSmellpath());
                File f = new File(s.getSmellpath());
                boolean exists = f.exists();
                if (exists) {
                    fieldContent.append(s.toString() + " FILE EXISTS" + "\n");
                    System.out.println(s.getFilepath());
                    smellOrNot[count]="no";

                } else {
                    fieldContent.append(s.toString() + " FILE DOES NOT EXIST" + "\n");
                    smellOrNot[count]="yes";
                    smell++;
                }
                count++;
            }
            System.out.println(count);
            result.setText(fieldContent.toString());
            detected.setText("Results Found!"+ "    Smell Count: "+smell);
            detected.setTextFill(Paint.valueOf("greenyellow"));
            result.setVisible(true);
            saveButton.setVisible(true);
            ArrayList<Result> finalResults = results;
            final int[] countSmell = {0};
            saveButton.setOnAction((EventHandler) event -> {
                String saveFilepath=showInputTextDialog();
                try (PrintWriter writer = new PrintWriter(new File(saveFilepath+".csv"))) {

                    StringBuilder sb = new StringBuilder();
                    sb.append("FileName,Path of smell, Line Number, Smell");
                    sb.append('\n');

                    for (Result s: finalResults){
                        sb.append(s.getFilepath());
                        sb.append(",");
                        sb.append(s.getSmellpath());
                        sb.append(",");
                        sb.append(s.getLinenumber());
                        sb.append(",");
                        sb.append(smellOrNot[countSmell[0]]);
                        sb.append("\n");
                        countSmell[0]++;
                    }

                    writer.write(sb.toString());


                    System.out.println("done!");

                } catch (FileNotFoundException e) {
                    System.out.println(e.getMessage());
                }
                saveButton.setDisable(true);
            });

        }
    }
    private String showInputTextDialog() {

        TextInputDialog dialog = new TextInputDialog();

        dialog.setTitle("Save in CSV");
        dialog.setHeaderText("Enter file name");
        dialog.setContentText("Name:");

        Optional<String> result = dialog.showAndWait();
        String  filepath = null;
        //System.out.println(result.get());
        return result.get();
    }

}
